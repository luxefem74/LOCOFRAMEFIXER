LOCO FRAMEFIXER · SHAREABLE KIT · VERSION 1.2
================================================

BEFORE YOU BEGIN

You need a working local installation of ComfyUI, version 0.46.0 or later,
with its own Python and PyTorch. This ZIP adds the workflow and its
components; it does not include ComfyUI or PyTorch.

The kit already includes the updated LOCO nodes, the VideoHelperSuite source
code, the ProRes 422 HQ preset, and two workflows with no references to files
on the original computer. You do not need to look for VideoHelperSuite in
the Manager or install Git.

An internet connection is required during initial setup to install the Python
dependencies, and on the first run to download SPEED (approximately 447 MiB
of model weights, plus the small official runtime). Once downloaded, the LOCO
engine generates frames locally. The LOCO nodes do not upload your videos
to a remote service.

GUIDED INSTALLATION ON MAC

1. Extract the entire ZIP into a regular folder.
2. Open INSTALLA_MAC.command. If macOS prevents the file from launching, use
   the manual installation instructions below.
3. Select the folder for YOUR ComfyUI installation:
   - Recent Comfy Desktop versions: the installation folder inside
     ComfyUI-Installs, or its ComfyUI subfolder containing main.py and
     custom_nodes.
   - Older Desktop versions: the data folder containing custom_nodes and .venv.
   - Manual installation: the folder containing main.py and custom_nodes.
   Do not select Comfy Desktop.app in the Applications folder.
4. Wait for INSTALLAZIONE COMPLETATA ("INSTALLATION COMPLETE"), then restart
   ComfyUI.
5. Drag workflow/01_PROVA_1_FRAME.json onto the canvas for an initial test.

GUIDED INSTALLATION ON WINDOWS

1. Extract the entire ZIP. Do not launch the installer directly from the archive.
2. Open INSTALLA_WINDOWS.bat.
3. Select your ComfyUI installation folder. For Portable installations, you can
   select either the folder containing ComfyUI and python_embeded, or the
   ComfyUI folder itself.
4. Wait for INSTALLAZIONE COMPLETATA ("INSTALLATION COMPLETE"), then restart
   ComfyUI.
5. Open workflow/01_PROVA_1_FRAME.json and load your video.

The graphical launcher uses tools provided by the operating system. The Python
installer always uses the Python interpreter found in the selected installation.
If your installation uses a Conda environment or a different path, follow the
manual procedure with the correct interpreter.

WHAT THE INSTALLER DOES

- Verifies the included files and checks for ComfyUI's Python and PyTorch.
- Installs einops, omegaconf, opencv-python, and imageio-ffmpeg in that
  environment. It keeps the existing versions of key ComfyUI packages pinned.
- Copies ComfyUI-LOCO-FrameRepair into custom_nodes.
- Installs the included VideoHelperSuite if no active copy is found.
  If one is already installed, it preserves the existing code and adds only
  the ProRes preset.
- Copies LOCO-ProRes422HQ.json into VideoHelperSuite's video_formats folder.
- If older LOCO nodes or an older preset are found, it first backs them up to
  ComfyUI/user/LOCO_install_backups/ with a date and time stamp.
- Writes ComfyUI/user/LOCO_FRAMEFIXER_installazione.json, recording the paths
  used.

FIRST USE

1. Open workflow/01_PROVA_1_FRAME.json.
2. In the Load Video node, load a video containing at least 25 frames.
3. Leave device=cpu and click Run. The model downloads automatically.
4. The preview shows: previous original frame / generated frame / next original frame.
5. Once the test works, open workflow/LOCO_FRAMEFIXER_PRORES.json.
6. Load your video and click Run.

The default values are first_after=24, interval=24, and max_gaps=0.
This means: insert one frame after original frames 24, 48, 72, and so on,
through the last valid pair. Indices start at 1 and always count original
frames, excluding any frames already inserted. The workflow applies the
preset; it does not automatically detect the defect's interval. The filter
for obvious scene cuts is a heuristic aid.

Do not change force_rate=0, custom_width=0, custom_height=0, format=None,
skip_first_frames=0, or select_every_nth=1 in the Load Video node.

On Mac, use CPU. MPS is not enabled for SPEED. On a machine with an NVIDIA
GPU, you can try CUDA; this release does not include CUDA benchmarking or
verification.

OUTPUT

Files are saved to the output folder configured in YOUR installation:

- LOCO_SPEED_PNG_PRORES/sequenza_DATA_ORA/: all PNG frames, both original
  and generated.
- LOCO_SPEED_PNG_PRORES/prores/: ProRes 422 HQ MOV files, 4:2:2, 10-bit, Rec.709.
- LOCO_SPEED_PNG_PRORES/solo_generati/: generated PNG frames only.
- LOCO_SPEED/: JSON reports with indices, dimensions, FPS, and duration.

The MOV is created from the same frames held in memory after the PNG files
have been saved. The PNG files are 8-bit RGB; ProRes is still a lossy re-encode.
This is an SDR/Rec.709 workflow; it is not a native HDR, ACES, or 10/12-bit
input pipeline. The 10-bit ProRes container does not recover precision missing
from the RGB data.

The output has no audio. Inserting frames while keeping the same FPS increases
the duration by 1/FPS seconds per insertion. Audio and edit points must be
realigned during finishing when necessary. Do not run the repair twice on the
same already-corrected file.

The entire sequence is held in RAM. Start with a short Full HD clip.
UHD footage or long clips can require substantial memory; work in shorter
segments and check the resources available on your colleague's computer.

MANUAL INSTALLATION (MAC, WINDOWS, LINUX)

1. Copy componenti/ComfyUI-LOCO-FrameRepair into ComfyUI/custom_nodes/.
2. If VideoHelperSuite is not installed, also copy
   componenti/ComfyUI-VideoHelperSuite into ComfyUI/custom_nodes/.
   Do not create two active copies of the same package.
3. Copy preset/LOCO-ProRes422HQ.json into the video_formats folder of the
   VideoHelperSuite installation you will use.
4. In a terminal with ComfyUI's Python environment activated, run the following
   command from this kit's folder:

   python -m pip install -r python_requirements.txt

   Use the name or path of the Python interpreter belonging to your installation.
   On Windows Portable, this is usually ..\python_embeded\python.exe; in a Mac
   virtual environment, it may be /percorso/ComfyUI/.venv/bin/python3.
   If pip is unavailable but uv is installed as a module, use:

   python -m uv pip install --python /percorso/del/python/di/ComfyUI -r python_requirements.txt

5. Restart ComfyUI and open one of the JSON files in the workflow folder.

Alternatively, the installer accepts explicit paths:

   python installa.py --comfy-root "/percorso/ComfyUI" --python "/percorso/python"

Use --check-only to verify the paths without installing anything.
Use --skip-deps to check imports and copy the components only if the
dependencies are already installed.

TROUBLESHOOTING

- Missing LOCO nodes: check that __init__.py is directly inside
  custom_nodes/ComfyUI-LOCO-FrameRepair/, then restart.
- Missing video/LOCO-ProRes422HQ: check that the preset is in the video_formats
  folder of the active VideoHelperSuite installation, then restart.
- Python not found: select the correct folder or use --python with the path
  shown in ComfyUI's startup logs. You do not need to install another system
  Python.
- Download blocked by TLS issues: on Mac, the runtime uses the system curl
  with HTTPS verification enabled. Previously downloaded official files can
  be copied into ComfyUI/models/loco-speed/, keeping the filenames specified
  in COMPONENTI.json and speed_runtime.py. Checksums are verified before loading.
- The video loads, but frames are not generated: check the clip length, first
  frame index, exclusions, and scene-cut filter in the LOCO node.

COMPONENTS AND VERIFICATION

VideoHelperSuite is included as source code under its GPL-3.0 license.
The LOCO integration retains its MIT license. These are separate works;
each component retains its own terms. SPEED is downloaded from official
sources and is not redistributed in this ZIP. Sources and commits are listed
in COMPONENTI.json.

See VERIFICHE_KIT.json for the tests performed. The original engine was tested
by the user on a Mac M4 Pro with Full HD footage. The kit's new graphical
launchers are not certified to work on every Mac or Windows system.
