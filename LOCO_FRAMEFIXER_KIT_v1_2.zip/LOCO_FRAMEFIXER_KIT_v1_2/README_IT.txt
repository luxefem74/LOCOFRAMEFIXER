LOCO FRAMEFIXER · KIT DA CONDIVIDERE · VERSIONE 1.2
================================================

PRIMA DI INIZIARE

Serve una installazione locale di ComfyUI gia funzionante, versione 0.46.0 o
successiva, con il proprio Python e PyTorch. Questo ZIP aggiunge il workflow e
i suoi componenti: non contiene l'applicazione ComfyUI o PyTorch.

Il kit comprende gia i nodi LOCO aggiornati, il codice di VideoHelperSuite,
il preset ProRes 422 HQ e due workflow senza riferimenti ai file del computer originale.
Non serve cercare VideoHelperSuite nel Manager o installare Git.

Internet serve durante la prima configurazione per le dipendenze Python e
al primo Run per SPEED (~447 MiB di pesi, piu il piccolo runtime ufficiale).
Dopo il download il motore LOCO genera i frame localmente. I video non vengono
caricati su un servizio remoto dai nodi LOCO.

INSTALLAZIONE GUIDATA SU MAC

1. Estrai tutto lo ZIP in una cartella normale.
2. Apri INSTALLA_MAC.command. Se macOS non permette l'avvio del file, usa
   l'installazione manuale indicata piu sotto.
3. Seleziona la cartella della TUA installazione ComfyUI:
   - Comfy Desktop recente: la cartella dell'installazione in ComfyUI-Installs,
     oppure la sua sottocartella ComfyUI con main.py e custom_nodes.
   - Desktop precedente: la cartella dati con custom_nodes e .venv.
   - Installazione manuale: la cartella con main.py e custom_nodes.
   Non selezionare Comfy Desktop.app nella cartella Applicazioni.
4. Attendi INSTALLAZIONE COMPLETATA e riavvia ComfyUI.
5. Trascina workflow/01_PROVA_1_FRAME.json sul canvas per una prima prova.

INSTALLAZIONE GUIDATA SU WINDOWS

1. Estrai tutto lo ZIP: non avviare il file direttamente dall'archivio.
2. Apri INSTALLA_WINDOWS.bat.
3. Seleziona la cartella della installazione ComfyUI. Per Portable puoi scegliere
   la cartella con ComfyUI e python_embeded, oppure direttamente ComfyUI.
4. Attendi INSTALLAZIONE COMPLETATA e riavvia ComfyUI.
5. Apri workflow/01_PROVA_1_FRAME.json e carica il tuo video.

L'avvio grafico usa gli strumenti del sistema operativo. L'installer Python
opera sempre sul Python individuato nella installazione scelta. Se la tua
installazione usa un ambiente Conda o un percorso diverso, usa la procedura
manuale con l'interprete corretto.

COSA FA L'INSTALLER

- Verifica i file distribuiti e la presenza del Python/PyTorch di ComfyUI.
- Installa einops, omegaconf, opencv-python e imageio-ffmpeg in quell'ambiente.
  Mantiene vincolate le versioni gia presenti dei principali pacchetti ComfyUI.
- Copia ComfyUI-LOCO-FrameRepair in custom_nodes.
- Installa il VideoHelperSuite incluso se non ne trova gia una copia attiva.
  Se e gia presente, conserva il suo codice e aggiunge soltanto il preset ProRes.
- Copia LOCO-ProRes422HQ.json nella cartella video_formats di VideoHelperSuite.
- Se trova vecchi nodi LOCO o un vecchio preset, li copia prima in
  ComfyUI/user/LOCO_install_backups/ con data e ora.
- Scrive ComfyUI/user/LOCO_FRAMEFIXER_installazione.json con i percorsi usati.

PRIMO UTILIZZO

1. Apri workflow/01_PROVA_1_FRAME.json.
2. Nel nodo Load Video carica un tuo file di almeno 25 fotogrammi.
3. Lascia device=cpu e premi Run. Il modello si scarica automaticamente.
4. La preview mostra: originale prima / generato / originale dopo.
5. Quando la prova funziona, apri workflow/LOCO_FRAMEFIXER_PRORES.json.
6. Carica il video e premi Run.

I valori iniziali sono first_after=24, interval=24, max_gaps=0.
Vuol dire: inserisci un frame dopo gli originali 24, 48, 72... fino all'ultima
coppia valida. Gli indici partono da 1 e contano sempre gli originali, non i
fotogrammi gia inseriti. Il workflow applica il preset: non diagnostica da solo
la cadenza del difetto. Il filtro sui tagli evidenti e un aiuto euristico.

Non cambiare force_rate=0, custom_width=0, custom_height=0, format=None,
skip_first_frames=0 e select_every_nth=1 nel nodo Load Video.

Su Mac usa CPU. MPS non e abilitato per SPEED. Su una macchina NVIDIA puoi
provare CUDA; questa consegna non include un benchmark o una verifica CUDA.

OUTPUT

I file finiscono nella cartella output configurata nella TUA installazione:

- LOCO_SPEED_PNG_PRORES/sequenza_DATA_ORA/: tutti i PNG, originali e nuovi.
- LOCO_SPEED_PNG_PRORES/prores/: MOV ProRes 422 HQ, 4:2:2, 10 bit, Rec.709.
- LOCO_SPEED_PNG_PRORES/solo_generati/: soltanto i nuovi PNG.
- LOCO_SPEED/: report JSON con indici, dimensioni, FPS e durata.

Il MOV e creato dagli stessi frame in memoria dopo il salvataggio dei PNG.
I PNG sono RGB 8 bit; il ProRes resta una ricodifica con perdita. Questo e un
percorso SDR/Rec.709: non e una pipeline nativa HDR, ACES o 10/12 bit in ingresso.
Il contenitore ProRes a 10 bit non recupera precisione assente nei dati RGB.

L'output e muto. Inserire frame mantenendo gli FPS aumenta la durata di
1/FPS secondi per intervento: l'audio e i punti di montaggio vanno riallineati
in finishing quando necessario. Non applicare il ripristino due volte allo
stesso file gia corretto.

La sequenza completa e tenuta in RAM. Inizia con una clip breve Full HD.
Per UHD o clip lunghe il consumo puo diventare elevato; lavora su spezzoni e
verifica le risorse disponibili sulla macchina del collega.

INSTALLAZIONE MANUALE (MAC, WINDOWS, LINUX)

1. Copia componenti/ComfyUI-LOCO-FrameRepair in ComfyUI/custom_nodes/.
2. Se manca VideoHelperSuite, copia anche componenti/ComfyUI-VideoHelperSuite
   in ComfyUI/custom_nodes/. Non creare due copie attive dello stesso pacchetto.
3. Copia preset/LOCO-ProRes422HQ.json nella cartella video_formats della copia
   di VideoHelperSuite che userai.
4. Nel terminale con il Python di ComfyUI attivo, dalla cartella di questo kit:

   python -m pip install -r python_requirements.txt

   Usa il nome o il percorso del Python della tua installazione. Su Portable
   Windows e generalmente ..\python_embeded\python.exe; su un virtualenv Mac
   puo essere /percorso/ComfyUI/.venv/bin/python3. Se pip non e disponibile ma
   e installato uv come modulo, usa:

   python -m uv pip install --python /percorso/del/python/di/ComfyUI -r python_requirements.txt

5. Riavvia ComfyUI e apri uno dei JSON nella cartella workflow.

In alternativa, l'installer accetta percorsi espliciti:

   python installa.py --comfy-root "/percorso/ComfyUI" --python "/percorso/python"

Con --check-only verifica i percorsi senza installare. Con --skip-deps verifica
gli import e copia i componenti soltanto se le dipendenze sono gia presenti.

SE QUALCOSA NON VA

- Nodi LOCO mancanti: controlla che __init__.py sia direttamente nella cartella
  custom_nodes/ComfyUI-LOCO-FrameRepair/, poi riavvia.
- video/LOCO-ProRes422HQ mancante: controlla che il preset sia nella cartella
  video_formats della copia attiva di VideoHelperSuite e riavvia.
- Python non trovato: scegli la cartella corretta o usa --python col percorso
  mostrato nei log di avvio ComfyUI. Non serve installare un altro Python di sistema.
- Download TLS bloccato: su Mac il runtime usa il curl di sistema con verifica
  HTTPS attiva. I file ufficiali gia scaricati possono essere copiati in
  ComfyUI/models/loco-speed/ mantenendo i nomi previsti in COMPONENTI.json e
  speed_runtime.py; i checksum vengono verificati prima del caricamento.
- Se il video si apre ma mancano i frame da generare, verifica lunghezza,
  primo indice, esclusioni e filtro sui tagli nel nodo LOCO.

COMPONENTI E VERIFICHE

VideoHelperSuite e incluso come codice sorgente con la propria licenza GPL-3.0.
L'integrazione LOCO conserva la sua licenza MIT. I componenti sono opere
distinte; ogni componente conserva i propri termini. SPEED viene scaricato
dalle fonti ufficiali e non e redistribuito in questo ZIP. Origini e commit
sono riportati in COMPONENTI.json.

Consulta VERIFICHE_KIT.json per i test eseguiti. Il motore originale e stato
verificato dall'utente su Mac M4 Pro, Full HD; i nuovi avvii grafici del kit
non sono una certificazione di funzionamento su ogni Mac o Windows.
