from __future__ import annotations

import json
import math
from pathlib import Path
import re
import threading

import torch
import torch.nn.functional as F

import folder_paths
import comfy.model_management
import comfy.utils

from .speed_runtime import SPEEDRuntime, ensure_assets

_cpu_lock = threading.Lock()


def parse_positions(text):
    text = text.strip()
    if not text:
        return []
    if not re.fullmatch(r"\d+(?:[\s,;]+\d+)*", text):
        raise ValueError("Posizioni: usa interi separati da virgole, es. 24,48,72.")
    return sorted(set(int(x) for x in re.split(r"[\s,;]+", text)))


def positions_for(count, first_after, interval, max_gaps, manual_after, exclude_after):
    positions = parse_positions(manual_after)
    if not manual_after.strip():
        positions = list(range(int(first_after), count, int(interval)))
        if max_gaps:
            positions = positions[:max_gaps]
    if any(p < 1 or p >= count for p in positions):
        raise ValueError(f"Ogni posizione deve avere due estremi reali: da 1 a {count-1}.")
    excluded = set(parse_positions(exclude_after))
    return [p for p in positions if p not in excluded]


def is_obvious_cut(a, b, threshold):
    # Conservative heuristic, not a replacement for reviewing marked positions.
    small = F.interpolate(torch.cat((a, b)).permute(0, 3, 1, 2),
                          size=(32, 32), mode="area")
    return float((small[0] - small[1]).abs().mean()) > threshold


def insert_audio_gaps(audio, positions, fps):
    """Insert precisely rounded silence intervals at the same original frame boundaries."""
    try:
        waveform, rate = audio["waveform"], int(audio["sample_rate"])
    except (KeyError, TypeError):
        return None
    if waveform is None or waveform.numel() == 0:
        return None
    parts, cursor = [], 0
    for i, position in enumerate(positions):
        boundary = min(waveform.shape[-1], round(position * rate / fps))
        parts.append(waveform[..., cursor:boundary])
        # Difference of rounded cumulative durations prevents sample drift.
        length = round((i + 1) * rate / fps) - round(i * rate / fps)
        parts.append(waveform.new_zeros((*waveform.shape[:-1], length)))
        cursor = boundary
    parts.append(waveform[..., cursor:])
    return {"waveform": torch.cat(parts, dim=-1), "sample_rate": rate}


class LOCOLoadSPEED:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {}}

    RETURN_TYPES = ("LOCO_SPEED_MODEL",)
    RETURN_NAMES = ("model",)
    FUNCTION = "load"
    CATEGORY = "LOCO/Frame Repair"
    DESCRIPTION = "Scarica e verifica SPEED ufficiale (~447 MiB). Nessun login o servizio cloud."

    def load(self):
        source, checkpoint = ensure_assets(Path(folder_paths.models_dir) / "loco-speed")
        return (SPEEDRuntime(source, checkpoint),)


class LOCORepairSPEED:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "model": ("LOCO_SPEED_MODEL",),
                "video_info": ("VHS_VIDEOINFO",),
                "first_after": ("INT", {"default": 24, "min": 1, "max": 1000000}),
                "interval": ("INT", {"default": 24, "min": 1, "max": 1000000}),
                "max_gaps": ("INT", {"default": 0, "min": 0, "max": 10000}),
                "manual_after": ("STRING", {"default": ""}),
                "exclude_after": ("STRING", {"default": ""}),
                "seed": ("INT", {"default": 1234, "min": 0, "max": 2147483647,
                                  "control_after_generate": False}),
                "device": (["cpu", "cuda"], {"default": "cpu"}),
                "cpu_threads": ("INT", {"default": 4, "min": 1, "max": 32}),
                "skip_obvious_cuts": ("BOOLEAN", {"default": True}),
                "cut_threshold": ("FLOAT", {"default": 0.35, "min": 0.05, "max": 1.0, "step": 0.01}),
                "audio_mode": (["mute", "insert_silence"], {"default": "mute"}),
            },
            "optional": {"audio": ("AUDIO",)},
        }

    RETURN_TYPES = ("IMAGE", "IMAGE", "IMAGE", "FLOAT", "AUDIO", "STRING")
    RETURN_NAMES = ("repaired", "generated_only", "triplets_A_new_B", "fps", "audio", "report")
    FUNCTION = "repair"
    CATEGORY = "LOCO/Frame Repair"
    DESCRIPTION = ("Inserisce un frame generativo solo dopo gli indici indicati. "
                   "Indici dei frame ORIGINALI, a partire da 1. Nessun rallentamento 2x.")

    @torch.inference_mode()
    def repair(self, images, model, video_info, first_after=24, interval=24, max_gaps=0,
               manual_after="", exclude_after="", seed=1234, device="cpu", cpu_threads=4,
               skip_obvious_cuts=True, cut_threshold=0.35, audio_mode="mute", audio=None):
        if images.ndim != 4 or images.shape[-1] != 3 or len(images) < 2:
            raise ValueError("Servono almeno due frame RGB nel batch IMAGE.")
        fps = float(video_info["loaded_fps"])
        if not math.isfinite(fps) or fps <= 0:
            raise ValueError("FPS non valido nel video_info.")
        source_fps = float(video_info.get("source_fps", fps))
        if abs(fps - source_fps) > 0.01:
            raise ValueError("Disattiva force_rate e select_every_nth nel Load Video: gli indici devono riferirsi agli originali.")
        if device == "cuda" and not torch.cuda.is_available():
            raise ValueError("CUDA non disponibile. Su Mac seleziona cpu.")
        count = len(images)
        requested = positions_for(count, first_after, interval, max_gaps,
                                  manual_after, exclude_after)
        selected, skipped = [], []
        for p in requested:
            if skip_obvious_cuts and is_obvious_cut(images[p-1:p], images[p:p+1], cut_threshold):
                skipped.append(p)
            else:
                selected.append(p)
        if not selected:
            raise ValueError("Nessun salto da generare: controlla posizioni, numero frame ed esclusioni/tagli.")
        patches = []
        progress = comfy.utils.ProgressBar(len(selected))
        # CPU thread count is process-global: restore it even on cancellation/failure.
        with _cpu_lock, model.lock:
            old_threads = torch.get_num_threads()
            try:
                if device == "cpu":
                    torch.set_num_threads(cpu_threads)
                model.to(device)
                for p in selected:
                    comfy.model_management.throw_exception_if_processing_interrupted()
                    patch = model.midpoint(images[p-1:p], images[p:p+1],
                                           (int(seed) + p) % 2147483648, device)
                    if tuple(patch.shape) != (1, *images.shape[1:]) or not torch.isfinite(patch).all():
                        raise RuntimeError(f"Frame SPEED non valido dopo l'originale {p}.")
                    patches.append(patch.to(device=images.device, dtype=images.dtype))
                    progress.update(1)
            finally:
                model.to("cpu")
                model.clear_cache()
                if device == "cpu":
                    torch.set_num_threads(old_threads)
        pieces, triplets, cursor = [], [], 0
        for p, patch in zip(selected, patches):
            pieces.extend((images[cursor:p], patch))
            triplets.extend((images[p-1:p], patch, images[p:p+1]))
            cursor = p
        pieces.append(images[cursor:])
        output = torch.cat(pieces)
        new_audio = insert_audio_gaps(audio, selected, fps) if audio_mode == "insert_silence" else None
        report = json.dumps({
            "model": "SPEED pixel diffusion, one step, midpoint",
            "device": device, "seed_base": int(seed),
            "resolution": [int(images.shape[2]), int(images.shape[1])],
            "source_frames": count, "output_frames": len(output), "fps": fps,
            "insert_after_original_1based": selected,
            "new_positions_1based": [p+i+1 for i, p in enumerate(selected)],
            "skipped_possible_cuts": skipped,
            "source_seconds": count / fps, "output_seconds": len(output) / fps,
            "audio_mode": audio_mode,
            "audio_present": new_audio is not None,
            "originals_preserved_in_image_batch": True,
        }, ensure_ascii=False, indent=2)
        return (output, torch.cat(patches), torch.cat(triplets), fps, new_audio, report)


class LOCOSaveReport:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"report": ("STRING", {"forceInput": True})}}

    RETURN_TYPES = ()
    FUNCTION = "save"
    OUTPUT_NODE = True
    CATEGORY = "LOCO/Frame Repair"

    def save(self, report):
        folder, filename, counter, subfolder, _ = folder_paths.get_save_image_path(
            "LOCO_SPEED/report", folder_paths.get_output_directory())
        Path(folder, f"{filename}_{counter:05}.json").write_text(report, encoding="utf-8")
        return {"ui": {"text": [report]}}


NODE_CLASS_MAPPINGS = {
    "LOCOLoadSPEED": LOCOLoadSPEED,
    "LOCORepairSPEED": LOCORepairSPEED,
    "LOCOSaveReport": LOCOSaveReport,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "LOCOLoadSPEED": "LOCO · Carica SPEED generativo",
    "LOCORepairSPEED": "LOCO · Genera solo i frame mancanti",
    "LOCOSaveReport": "LOCO · Salva report riparazione",
}
