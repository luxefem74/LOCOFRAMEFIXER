"""Minimal inference-only adapter. Upstream code/weights are downloaded, not bundled."""
from __future__ import annotations

import hashlib
import importlib
import logging
import os
from pathlib import Path
import ssl
import subprocess
import sys
import tempfile
import threading
import types
import urllib.request
import zipfile

import torch

SOURCE_COMMIT = "40fadbe85c88cc6e4015062389da464fd7e85ab9"
SOURCE_SHA256 = "9e9cc71bfeaf7a62008950b8f234f5f035df27b65a5fc0464caee2542f47f68c"
WEIGHTS_SHA256 = "abd078f6a1135a84e13f0003e996d121d4adc2c41adf5f67d933c76c958243cd"
SOURCE_URL = f"https://codeload.github.com/bbldCVer/SPEED/zip/{SOURCE_COMMIT}"
WEIGHTS_URL = "https://huggingface.co/zhZ524/SPEED/resolve/main/speed.pt?download=true"
_download_lock = threading.Lock()
log = logging.getLogger("LOCO-FrameRepair")


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _download(url, temporary, name):
    # Standalone Python on macOS can have a different CA store from the OS.
    # Apple's curl uses its configured TLS backend and verifies certificates.
    # Do not add --insecure/-k, change global SSL settings, or modify keychains.
    if sys.platform == "darwin" and Path("/usr/bin/curl").is_file():
        log.info("Download %s con il downloader di macOS; verifica HTTPS attiva.", name)
        result = subprocess.run([
            "/usr/bin/curl", "--fail", "--location", "--silent", "--show-error",
            "--proto", "=https", "--proto-redir", "=https",
            "--connect-timeout", "30", "--max-time", "3600",
            "--retry", "2", "--output", str(temporary), url,
        ], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=3630)
        if result.returncode:
            reason = result.stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(
                f"Download macOS non riuscito per {name}: {reason}. "
                "La verifica dei certificati resta attiva. Controlla rete/proxy "
                "oppure scarica i due file ufficiali dal browser come indicato nel LEGGIMI.")
        return
    context = ssl.create_default_context()
    try:
        import certifi
    except ImportError:
        pass
    else:
        context.load_verify_locations(cafile=certifi.where())
    request = urllib.request.Request(url, headers={"User-Agent": "LOCO-FrameRepair/1.1"})
    with urllib.request.urlopen(request, timeout=90, context=context) as response:
        size = int(response.headers.get("Content-Length", 0))
        received, next_log = 0, 0
        with open(temporary, "wb") as f:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                f.write(block)
                received += len(block)
                if received >= next_log:
                    log.info("Download %s: %.0f / %.0f MiB", name,
                             received / 2**20, size / 2**20)
                    next_log = received + 32 * 2**20


def fetch(url, target, expected):
    """Atomic verified transfer; macOS uses its native curl, other OS use Python."""
    target = Path(target)
    if target.is_file() and digest(target) == expected:
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".part", delete=False) as f:
            temporary = Path(f.name)
        _download(url, temporary, target.name)
        if digest(temporary) != expected:
            raise RuntimeError(f"Checksum non valido per {target.name}; download rifiutato.")
        os.replace(temporary, target)
    finally:
        if temporary and temporary.exists():
            temporary.unlink()


def ensure_assets(model_dir):
    root = Path(model_dir)
    source = root / f"SPEED-{SOURCE_COMMIT}"
    with _download_lock:
        archive = root / f"source-{SOURCE_COMMIT}.zip"
        fetch(SOURCE_URL, archive, SOURCE_SHA256)
        if not (source / "src/models/model.py").is_file():
            with zipfile.ZipFile(archive) as z:
                for member in z.infolist():
                    destination = (root / member.filename).resolve()
                    if not destination.is_relative_to(root.resolve()):
                        raise RuntimeError("Percorso non valido nell'archivio SPEED.")
                z.extractall(root)
        weights = root / "speed.pt"
        fetch(WEIGHTS_URL, weights, WEIGHTS_SHA256)
    return source, weights


def speed_class(source):
    """Avoid adding the generic upstream 'src' name to the global import path."""
    for name, path in (("_loco_speed", source),
                       ("_loco_speed.src", source / "src"),
                       ("_loco_speed.src.models", source / "src/models")):
        if name not in sys.modules:
            package = types.ModuleType(name)
            package.__path__ = [str(path)]
            package.__package__ = name
            sys.modules[name] = package
    return importlib.import_module("_loco_speed.src.models.model").SpeedDiT


class SPEEDRuntime:
    def __init__(self, source, checkpoint):
        self.lock = threading.Lock()
        self.model = speed_class(Path(source))(
            hidden_dim=768, head_dim=64, depths=(2, 6, 4), patch_sizes=(64, 32, 16))
        # The official training checkpoint includes non-tensor metadata. Verify
        # its pinned digest before permitting Python pickle deserialization.
        if digest(checkpoint) != WEIGHTS_SHA256:
            raise RuntimeError("Checkpoint SPEED diverso da quello ufficiale verificato.")
        data = torch.load(checkpoint, map_location="cpu", weights_only=False)
        state = data.get("model", data)
        if state and all(k.startswith("module.") for k in state):
            state = {k[7:]: v for k, v in state.items()}
        self.model.load_state_dict(state, strict=True)
        self.model.requires_grad_(False).eval()

    def to(self, device):
        self.model.to(device=device, dtype=torch.float32)
        return self

    def clear_cache(self):
        self.model.rope_embedder.rope_cache.clear()

    @torch.inference_mode()
    def midpoint(self, before, after, seed, device):
        """BHWC RGB [0,1] -> BHWC; official one-step denoising at t=1000."""
        a = before.to(device=device, dtype=torch.float32).permute(0, 3, 1, 2) * 2 - 1
        b = after.to(device=device, dtype=torch.float32).permute(0, 3, 1, 2) * 2 - 1
        generator = torch.Generator(device=device).manual_seed(int(seed))
        noise = torch.randn(a.shape, generator=generator, device=device, dtype=torch.float32)
        time = torch.full((a.shape[0],), 1000.0, device=device)
        result = self.model(noisy_frames=noise, cond_frames=torch.cat((a, b)), timestep=time)
        return ((result + 1) * 0.5).clamp(0, 1).permute(0, 2, 3, 1).cpu()
