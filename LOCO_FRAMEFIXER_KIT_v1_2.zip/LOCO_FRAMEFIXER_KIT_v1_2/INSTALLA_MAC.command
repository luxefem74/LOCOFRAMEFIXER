#!/bin/bash
set -eu
LOCO_KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
if ! LOCO_COMFY_DIR=$(/usr/bin/osascript -e 'POSIX path of (choose folder with prompt "LOCO FrameFixer: scegli la cartella della tua installazione ComfyUI (con main.py o custom_nodes).")'); then
  exit 0
fi
LOCO_PYTHON=""
for LOCO_CANDIDATE in \
  "$LOCO_COMFY_DIR/.venv/bin/python3" \
  "$LOCO_COMFY_DIR/.venv/bin/python" \
  "$LOCO_COMFY_DIR/ComfyUI/.venv/bin/python3" \
  "$LOCO_COMFY_DIR/ComfyUI/.venv/bin/python" \
  "$LOCO_COMFY_DIR/venv/bin/python3" \
  "$LOCO_COMFY_DIR/standalone-env/bin/python3" \
  "$LOCO_COMFY_DIR/../standalone-env/bin/python3"; do
  if [ -x "$LOCO_CANDIDATE" ]; then
    LOCO_PYTHON="$LOCO_CANDIDATE"
    break
  fi
done
if [ -z "$LOCO_PYTHON" ]; then
  LOCO_PYTHON="$(command -v python3 || true)"
fi
if [ -z "$LOCO_PYTHON" ]; then
  printf '%s\n' "Python non trovato. Consulta LEGGIMI_PRIMA.txt per l'installazione manuale."
  read -r -p "Premi Invio per chiudere. " LOCO_PAUSE
  exit 1
fi
LOCO_STATUS=0
if "$LOCO_PYTHON" "$LOCO_KIT_DIR/installa.py" --comfy-root "$LOCO_COMFY_DIR"; then
  printf '\n%s\n' "Ora riavvia ComfyUI e apri il JSON nella cartella workflow."
else
  LOCO_STATUS=1
  printf '\n%s\n' "Leggi l'errore qui sopra e consulta LEGGIMI_PRIMA.txt."
fi
read -r -p "Premi Invio per chiudere. " LOCO_PAUSE
exit "$LOCO_STATUS"
