"""Installa il kit in una ComfyUI esistente, usando il suo interprete Python."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

KIT = Path(__file__).resolve().parent
VERSION = "1.2"
CORE_PACKAGES = ("torch", "torchvision", "torchaudio", "numpy", "Pillow", "scipy",
                 "transformers", "tokenizers", "pydantic")


def sha256(path):
    result = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def verify_kit():
    manifest = json.loads((KIT / "SHA256SUMS.json").read_text(encoding="utf-8"))
    for name, expected in manifest.items():
        target = (KIT / name).resolve()
        if not target.is_relative_to(KIT) or not target.is_file():
            raise RuntimeError(f"File del kit mancante o percorso non valido: {name}")
        if sha256(target) != expected:
            raise RuntimeError(f"File del kit modificato o incompleto: {name}. Estrai di nuovo lo ZIP.")


def comfy_root(value):
    root = Path(value).expanduser().resolve()
    if (root / "main.py").is_file():
        return root
    if (root / "ComfyUI" / "main.py").is_file():
        return root / "ComfyUI"
    # Legacy Desktop stores custom_nodes and the venv in the selected data folder.
    if (root / "custom_nodes").is_dir() and (root / ".venv").is_dir():
        return root
    raise RuntimeError(
        "La cartella scelta non sembra una installazione ComfyUI. "
        "Seleziona la cartella che contiene main.py e custom_nodes, oppure la "
        "cartella Desktop che contiene custom_nodes e .venv.")


def python_candidates(root):
    relative = (
        ".venv/bin/python3", ".venv/bin/python", "venv/bin/python3", "venv/bin/python",
        ".venv/Scripts/python.exe", "venv/Scripts/python.exe",
        "python_embeded/python.exe", "python_embedded/python.exe",
        "../python_embeded/python.exe", "../python_embedded/python.exe",
        "../standalone-env/bin/python3", "../standalone-env/python.exe",
        "envs/default/bin/python3", "envs/default/python.exe",
    )
    # Keep the .venv symlink path: resolving the executable itself loses venv identity.
    return [Path(os.path.abspath(root / name)) for name in relative]


def choose_python(root, explicit=None):
    if explicit:
        candidate = Path(os.path.abspath(Path(explicit).expanduser()))
        if candidate.is_file():
            return candidate
        raise RuntimeError(f"Interprete Python non trovato: {candidate}")
    for candidate in python_candidates(root):
        if candidate.is_file():
            return candidate
    raise RuntimeError(
        "Non trovo il Python della tua installazione. Usa il comando manuale "
        "indicato nel LEGGIMI con --python e il percorso del Python usato da ComfyUI. "
        "Il kit non installa pacchetti nel Python di sistema automaticamente.")


def probe_python(python):
    code = '''import importlib.util, importlib.metadata, json, sys
import torch
names = ["torch", "torchvision", "torchaudio", "numpy", "Pillow", "scipy", "transformers", "tokenizers", "pydantic"]
versions = {}
for name in names:
    try: versions[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError: pass
print(json.dumps({"executable": sys.executable, "version": list(sys.version_info[:3]), "prefix":sys.prefix,
 "torch":torch.__version__, "versions":versions,
 "pip":importlib.util.find_spec("pip") is not None, "uv":importlib.util.find_spec("uv") is not None}))
'''
    result = subprocess.run([str(python), "-I", "-c", code], capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(
            "Il Python individuato non riesce a importare PyTorch. "
            "Verifica che questa installazione di ComfyUI funzioni prima di installare il kit.\n"
            + result.stderr[-2500:])
    info = json.loads(result.stdout.strip().splitlines()[-1])
    if tuple(info["version"]) < (3, 10):
        raise RuntimeError("Questo kit richiede Python 3.10 o successivo nell'ambiente ComfyUI.")
    return info


def check_comfy_version(root):
    path = root / "comfyui_version.py"
    if path.is_file():
        match = re.search(r'__version__\s*=\s*[\'"]([0-9]+)\.([0-9]+)\.([0-9]+)',
                          path.read_text(encoding="utf-8"))
        if match and tuple(map(int, match.groups())) < (0, 46, 0):
            raise RuntimeError("Aggiorna questa installazione a ComfyUI 0.46.0 o successivo prima di usare il kit.")


def verify_dependencies(python):
    code = "import einops,omegaconf,cv2,imageio_ffmpeg; print('Dipendenze importate correttamente.')"
    subprocess.run([str(python), "-I", "-c", code], check=True)


def install_dependencies(python, info):
    requirements = KIT / "python_requirements.txt"
    with tempfile.TemporaryDirectory(prefix="loco-constraints-") as temporary:
        constraints = Path(temporary) / "comfy-core.txt"
        constraints.write_text("\n".join(
            f"{name}=={info['versions'][name]}" for name in CORE_PACKAGES if name in info["versions"]
        ) + "\n", encoding="utf-8")
        if info["pip"]:
            command = [str(python), "-I", "-m", "pip", "install"]
        elif info["uv"]:
            command = [str(python), "-I", "-m", "uv", "pip", "install", "--python", str(python)]
        else:
            subprocess.run([str(python), "-I", "-m", "ensurepip", "--upgrade"], check=True)
            command = [str(python), "-I", "-m", "pip", "install"]
        subprocess.run(command + ["--constraint", str(constraints), "-r", str(requirements)], check=True)
    verify_dependencies(python)


def find_vhs(custom_nodes):
    if custom_nodes.is_dir():
        for child in sorted(custom_nodes.iterdir()):
            if child.is_dir() and not child.name.endswith(".disabled"):
                if (child / "videohelpersuite" / "nodes.py").is_file():
                    return child
    return None


def backup_existing(source, backup_root, name):
    if not source.exists():
        return False
    backup_root.mkdir(parents=True, exist_ok=True)
    destination = backup_root / name
    if source.is_dir():
        shutil.copytree(source, destination, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"))
    else:
        shutil.copy2(source, destination)
    return True


def install_files(root):
    custom = root / "custom_nodes"
    custom.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backups = root / "user" / "LOCO_install_backups" / stamp
    own = custom / "ComfyUI-LOCO-FrameRepair"
    backup_existing(own, backups, own.name)
    shutil.copytree(KIT / "componenti" / own.name, own, dirs_exist_ok=True)
    vhs = find_vhs(custom)
    existing_vhs = vhs is not None
    if vhs is None:
        vhs = custom / "ComfyUI-VideoHelperSuite"
        shutil.copytree(KIT / "componenti" / "ComfyUI-VideoHelperSuite", vhs)
    preset = vhs / "video_formats" / "LOCO-ProRes422HQ.json"
    backup_existing(preset, backups, "LOCO-ProRes422HQ.json")
    preset.parent.mkdir(exist_ok=True)
    shutil.copy2(KIT / "preset" / preset.name, preset)
    return {"custom_nodes":str(custom), "LOCO":str(own), "VideoHelperSuite":str(vhs),
            "existing_VideoHelperSuite_reused":existing_vhs,
            "ProRes_preset":str(preset), "backup":str(backups) if backups.exists() else None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comfy-root", required=True, help="Cartella della installazione ComfyUI")
    parser.add_argument("--python", help="Interprete Python usato da ComfyUI, se non rilevato automaticamente")
    parser.add_argument("--check-only", action="store_true", help="Verifica percorsi e Python senza installare")
    parser.add_argument("--skip-deps", action="store_true", help="Per ambienti con dipendenze gia installate; ne verifica gli import")
    args = parser.parse_args()
    verify_kit()
    root = comfy_root(args.comfy_root)
    check_comfy_version(root)
    python = choose_python(root, args.python)
    info = probe_python(python)
    print(f"ComfyUI: {root}\nPython: {python}\nPyTorch: {info['torch']}", flush=True)
    if args.check_only:
        print("Verifica completata. Nessun file o pacchetto e stato modificato.")
        return 0
    if args.skip_deps:
        verify_dependencies(python)
    else:
        print("Installazione delle dipendenze nell'ambiente ComfyUI...", flush=True)
        install_dependencies(python, info)
    result = install_files(root)
    result.update({"kit_version":VERSION,"python":str(python),"torch":info["torch"]})
    report = root / "user" / "LOCO_FRAMEFIXER_installazione.json"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\nINSTALLAZIONE COMPLETATA.\nRiavvia ComfyUI e apri workflow/LOCO_FRAMEFIXER_PRORES.json.")
    print("Il modello SPEED si scarica al primo Run (~447 MiB).")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nInstallazione interrotta.", file=sys.stderr)
        raise SystemExit(130)
    except (RuntimeError, OSError, subprocess.CalledProcessError, ValueError) as error:
        print(f"\nINSTALLAZIONE NON COMPLETATA: {error}", file=sys.stderr)
        raise SystemExit(1)
