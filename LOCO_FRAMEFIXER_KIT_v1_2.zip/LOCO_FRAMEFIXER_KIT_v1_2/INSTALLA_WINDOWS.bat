@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "LOCO_KIT_DIR=%~dp0"
set "LOCO_COMFY_DIR="
for /f "usebackq delims=" %%D in (`powershell.exe -NoProfile -STA -Command "Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = 'Seleziona la cartella della installazione ComfyUI'; if ($d.ShowDialog() -eq 'OK') { $d.SelectedPath }"`) do set "LOCO_COMFY_DIR=%%D"
if not defined LOCO_COMFY_DIR exit /b 0
set "LOCO_PYTHON="
for %%P in (
 "%LOCO_COMFY_DIR%\.venv\Scripts\python.exe"
 "%LOCO_COMFY_DIR%\ComfyUI\.venv\Scripts\python.exe"
 "%LOCO_COMFY_DIR%\venv\Scripts\python.exe"
 "%LOCO_COMFY_DIR%\python_embeded\python.exe"
 "%LOCO_COMFY_DIR%\python_embedded\python.exe"
 "%LOCO_COMFY_DIR%\..\python_embeded\python.exe"
 "%LOCO_COMFY_DIR%\..\python_embedded\python.exe"
 "%LOCO_COMFY_DIR%\standalone-env\python.exe"
 "%LOCO_COMFY_DIR%\..\standalone-env\python.exe"
) do if not defined LOCO_PYTHON if exist "%%~P" set "LOCO_PYTHON=%%~P"
if not defined LOCO_PYTHON (
 echo Python non trovato. Consulta LEGGIMI_PRIMA.txt per l'installazione manuale.
 pause
 exit /b 1
)
"%LOCO_PYTHON%" "%LOCO_KIT_DIR%installa.py" --comfy-root "%LOCO_COMFY_DIR%"
set "LOCO_STATUS=%ERRORLEVEL%"
if errorlevel 1 (
 echo Installazione non completata. Leggi l'errore qui sopra.
) else (
 echo Riavvia ComfyUI e apri il JSON nella cartella workflow.
)
pause
exit /b %LOCO_STATUS%
